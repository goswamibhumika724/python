d={"a":1,"b":2,"c":3}
print(list(d),list(d.values()),list(d.items()))
print(tuple(d),tuple(d.values()),tuple(d.items()))
print(set(d),set(d.values()),set(d.items()))
