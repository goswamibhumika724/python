'''
Docstring for p__37_for_loop_pattern_2

* * * * *
* * * *
* * * 
* *
*

'''
for row in range(6,1,-1):
    for astriek in range(1,row):
        print('*',end=' ')
    print(' ')