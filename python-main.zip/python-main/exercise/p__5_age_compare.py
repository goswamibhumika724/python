#5) write a program to find out elder brother from given two brother's age. 

brother1=int(input("ENTER THE AGE OF BROTHER 1 : "))
brother2=int(input("ENTER THE AGE OF BROTHER 2 : "))

if brother1>brother2:
    print("BROTHER 1 IS ELDER & BROTHER 2 IS OLDER")
else:
    print("BROTHER 2 IS ELDER & BROTHER 1 IS OLDER")