#7) write a program to decide which is cheaper approach to go from ahmedabad to delhi. by car or by train. consider person has his own petrol car  and he prefer to travel by 1st class train 


car=(986/20)*96   #(kilometer/mileage)*litre_price
train=3700

if bycar<bytrain:
    print("car is cheaper")
else:
    print("train is cheaper")