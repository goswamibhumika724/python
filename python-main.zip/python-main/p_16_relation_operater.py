 #WAP FOR PERFORM ALL THE RELATIONAL OPERATOR
 #NAME : KRISHNADEEPSINH
 #DATE:9/1/26

num1=int(input("ENTER NO 1 : "))
num2=int(input("ENTER NO 2 : "))

result = num1 == num2   #False
print(f"{result} = {num1} == {num2}")

result = num1 != num2   #True
print(f"{result} = {num1} != {num2}")

result=num1 < num2      #True
print(f"{result} = {num1} < {num2}")

result=num1 > num2      #False
print(f"{result} = {num1} > {num2}")

result=num1 <= num2     #True
print(f"{result} = {num1} <= {num2}")

result=num1 >= num2     #False
print(f"{result} = {num1} >= {num2}")
