#WAP TO CREATE VARAIBLE & STORE VALUE AND DISPLAY DETAILS 
#NAME=KRISHNADEEPSINH
#DATE=3/1/26

name="CHUDASAMA KRISHNADEEPSINH"           #VARIABLE DECLARE AND VALUE ASSIGN
address="CHITRA "
city="BHAVNAGAR"
pincode=364004
age=19
weight=82
gender="MALE"

print(" NAME = ",name)
print(" ADDRESS = ",address)
print(" CITY = ",city)
print(" PINCODE = ",pincode)
print(" AGE = ",age)
print(" WEIGHT = ",weight)
print(" GENDER = ",gender)