# write a program to print following serie
#4)   0    1   1   2   3   5   8   13  .... 100

