# write a program to print following series 
#   100  95  90  85  80  75  70  65  60  ..... 0

no=int(input("ENTER THE NUMBER : "))

while no>=0:
    
    print(no,end=' ')
    no-=5