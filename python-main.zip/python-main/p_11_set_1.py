#WAP CREATE A SET OF FRUITS AND PERFORM ADD & REMOVE ITEMS
fruits = {"apple", "banana", "mango", "orange", "grapes", "pineapple", "papaya", "kiwi", "strawberry", "watermelon"}

fruits.add("apple")    #ignore due to already in set data
fruits.add("mango")    #ignore due to already in set data
fruits.add("coconut")  #add the new fruits
fruits.remove("kiwi")  #kiwi removed from the set data
print(fruits)          #print all statment  
