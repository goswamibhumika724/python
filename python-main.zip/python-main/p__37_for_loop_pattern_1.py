'''
Docstring for p__36_for_loop_pattern_1
*
* *
* * * 
* * * *
* * * * *
'''



for row in range(1,6):
    for astreik in range(1,row+1):
        print('*',end=" ")

    print(" ")
