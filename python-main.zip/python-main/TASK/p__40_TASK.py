#40. Write a program to convert meters into kilometers.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

meter=int(input("ENTER THE METERS : "))
km=meter/1000
print("KILOMETER : ",km)