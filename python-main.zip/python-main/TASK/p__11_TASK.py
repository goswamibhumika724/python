#11. Create a dictionary of 5 students with their marks and find the total marks.
#NAME=KRISHNADEEPSINH
#DATE=11/1/26

stud={'KRISHNADEEPSINH':100,'YAGNADEEPSINH':90,'VIVEK R':70,'TUSHAR':80,'VIVEK S':81}

print(sum(stud.values()))
