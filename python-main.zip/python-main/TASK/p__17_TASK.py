#17. Create a list and find the second largest number using sorting.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

list1=[1,2,3,4,5,6,7,8,9,10,0]
list1.sort()
list1.reverse()
print(f"{list1[1]}")