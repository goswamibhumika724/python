#38. Write a program to calculate the square and cube of a number.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

no=int(input("ENTER NUMBER FOR SQUARE AND CUBE : "))
square=no*no
cube=no*no*no
print(f"SQUARE OF {no} = {square}")
print(f"CUBE OF {no} = {cube}")