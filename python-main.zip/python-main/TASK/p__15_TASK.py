#15. Create a list of numbers and remove all duplicate values without using loops.
#NAME=KRISHNADEEPSINH
#DATE=11/1/26

no=[1,2,3,4,5,1,10,1,2,3,4,5]
no=set(no)
no=list(no)
print(f"LIST IS {no}")
