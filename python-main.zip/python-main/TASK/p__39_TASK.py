#39. Write a program to calculate speed using distance and time.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

distance=float(input("ENTER DISTANCE IN KILOMETER : "))
time=int(input("ENTER TIME IN HOURS : "))
speed=distance/time
print("THE SPEED = ",speed)