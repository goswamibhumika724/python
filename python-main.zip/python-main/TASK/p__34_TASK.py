#34. Write a program to convert seconds into minutes.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

sec=int(input("ENTER THE SECONDS"))
min=sec//60
print("THE CONVERSTION OF SEC INTO MIN :",min)
