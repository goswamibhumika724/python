#24. Write a program to convert kilograms into grams.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

kilogram=float(input("ENTER KILOGRAM :"))
print(f"GRAMS ARE :{kilogram*1000}")