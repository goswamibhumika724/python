#1. Create a list of 10 numbers and find the sum using built-in functions.
#NAME=KRISHNADEEPSINH
#DATE=10/1/26

list=[1,2,3,4,5,6,7,8,9,10]


print(sum(list))