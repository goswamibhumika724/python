#3. Create a tuple of 5 elements and find its length.
#NAME=KRISHNADEEPSINH
#DATE=10/1/26

tuple=(1,2,3,4,5,'tuple')
print(len(tuple))