#21. Write a program to convert bytes into kilobytes.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

byte=int(input("ENTER BYTES :"))

print("BYTES ARE ",byte)
print(f"KILOBYTES ARE : {byte//1000}")
