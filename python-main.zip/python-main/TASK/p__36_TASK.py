#36. Write a program to calculate the total price of items.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

dic={'RAM':15000,'SSD':5500,'MOTHERBOARD':8000,'GTX1650_GPU':7500,'peripherials':3500}
print("THE TOTAL SUM OF ALL ITEMS ARE : ",sum(dic.values()))