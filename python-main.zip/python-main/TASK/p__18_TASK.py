#18. Given a list of words, create a set to find unique words.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

list1=['krish','yd','tushar','vivek','vivek','yd']

set1=set(list1)
print(f"UNIQUE LIST OF WORDS ARE : {set1}")
