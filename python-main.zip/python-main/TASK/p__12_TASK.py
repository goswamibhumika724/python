 #12. From a dictionary, extract only the keys into a list.
#NAME=KRISHNADEEPSINH
#DATE=11/1/26

dic={'NAME':'KRISHNADEEPSINH',"AGE":19,'GENDER':'MALE','DOB':'2-MAY-2006','HOBBIES':'READING'}
print(dic.keys())