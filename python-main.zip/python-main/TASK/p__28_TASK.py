#28. Write a program to calculate the area of a rectangle using length and breadth.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

l=int(input("ENTER THE LENGTH FOR RECTANGLE : "))
b=int(input("ENTER THE BREADTH FOR RECTANGLE : "))

print("AREA OF RECTANGLE IS : ",l*b)
