#5. Count how many times a specific value appears in a list using built-in methods.
##NAME=KRISHNADEEPSINH
#DATE=10/1/26


list1=[1,2,3,4,5,6,7,8,9,10,0,11,1,1,2]
print(list1.count(1))