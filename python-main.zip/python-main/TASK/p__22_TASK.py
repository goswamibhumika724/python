#22. Write a program to convert kilobytes into megabytes.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

kilobyte=int(input("ENTER KILOBYTES :"))
print(f"MEGABYTES ARE {kilobyte//1024}")