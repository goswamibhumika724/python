#31. Write a program to convert Celsius temperature into Fahrenheit.
#F = (C × 9/5) + 32

#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

c=float(input("ENTER THE CELSIUS : "))
f=(c*9/5)+32
print("THE TEMPERATURE IN FAHRENHEIT = ",f)
