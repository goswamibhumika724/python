#2. Given a list of numbers, find the maximum and minimum values.
#NAME=KRISHNADEEPSINH
#DATE=10/1/26

list=[10,20,55,45,98,54,32,12]
print("MAXIMUM NUMBERS IS :",max(list))
print("MINIMUN NUMBERS IS :",min(list))
