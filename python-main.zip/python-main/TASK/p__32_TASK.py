#32. Write a program to convert Fahrenheit temperature into Celsius.
#C = (F - 32) × 5/9

#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

f=float(input("ENTER THE FAHRENHEIT : "))
c=(f-32)*5/9
print("THE CELSIUS IS :",c)
