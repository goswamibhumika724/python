#23. Write a program to convert grams into kilograms.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26



gram=int(input("ENTER GRAM :"))
print(f"KILOGRAM ARE {gram//1000}")