#8. Create two sets and find their intersection
#NAME=KRISHNADEEPSINH
#DATE=10/1/26


set1={1,2,3,4,5}
set2={4,5,6,7,8}
set3=set1.intersection(set2)
print(set3)