#4. Reverse a list using slicing (no loop)
#NAME=KRISHNADEEPSINH
#DATE=10/1/26

list=[1,2,3,4,5,6,7,8,9,10,0]
list2=list[::-1]
print(list2)