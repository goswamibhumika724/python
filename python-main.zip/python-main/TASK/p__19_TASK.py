#19. Create a dictionary and calculate the average of all values.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26


dic={'sub1':70,'sub2':80,'sub3':90,'sub4':50,'sub5':40,'sub6':90,'sub7':80}
mark=dic.values()
print(f"AVERAGE OF MARKS ARE {sum(mark)/len(mark)}")



