#6. Convert a list with duplicate values into a set and display unique elements.
#NAME=KRISHNADEEPSINH
#DATE=10/1/26

list=[1,2,3,4,5,1,3,1]
print(list)
print(set(list))