#16. Given a tuple of numbers, convert it into a list and add new elements.
#NAME : KRISHNADEEPSINH
#DATE : 12/1/26

tup=(1,2,3,4,5)
tup=list(tup)
tup.append(10)
print(tup)