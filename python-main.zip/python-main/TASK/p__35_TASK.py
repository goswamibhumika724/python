#35. Write a program to convert minutes into hours.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

min=float(input("ENTER THE MINUTES : "))
hours=min//60
print("THE HOURS ARE : ",hours)
