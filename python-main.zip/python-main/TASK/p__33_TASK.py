#33. Write a program to calculate the average of marks.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26


mark=[90,70,80,60,66,45,79]

print(f"AVERAGE OF MARKS ARE {sum(mark)/len(mark)}")