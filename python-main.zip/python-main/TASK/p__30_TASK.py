#30. Write a program to calculate the area of a circle using radius.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

pi=3.14
radius=float(input("ENTER RADIUS FOR CRICLE :"))
print("THE AREA OF CRICLE IS :",pi*radius**2)