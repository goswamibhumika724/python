#27. Write a program to calculate the area of a triangle using base and height.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

base=int(input("ENTER THE BASE FOR TRIANGLE :"))
height=int(input("ENTER THE HEIGHT OF TRIANGLE :"))

print("AREA OF TRIANGLE IS :",0.5*base*height)