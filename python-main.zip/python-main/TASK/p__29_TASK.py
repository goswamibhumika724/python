#29. Write a program to calculate the perimeter of a rectangle.
#NAME : KRISHNADEEPSINH
#DATE : 13/1/26

l=int(input("ENTER THE LENGTH FOR RECTANGLE : "))
b=int(input("ENTER THE BREADTH FOR RECTANGLE : "))

print("THE PERIMETER OF RECTANGLE IS : ",2*(l+b))