# for loop with list 
# write a program to display only positive value in list 
list = [12, -45, 7, -3, 89, -22, 0, 34, -9, 56]

for item in list:
    if item>0:
        print(item)
    