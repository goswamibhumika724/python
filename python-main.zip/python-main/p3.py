#WAP TO CREATE LIST TO STORE & CREATE LIST 
# TO STORE 10 DIFFERNET VALUES IN IT 
#NAME=KRISHNADEEPSINH
#DATE=3/1/26

destination=["GOA","MANALI","BANGLORE","PUNE","JAIPUR","UDAIPUR",100,3.14,True,None]

print("ALL VALUES =",destination)                           #PRINT ALL VALUES
print("FIRST VALUE= ",destination[0])                       #PRINT FIRST VALUE
print("FIRST 5 VALUES = ",destination[0:5])                 #PRINT FIRST 5 VALUEs 
print("LAST 5 VALUES = ",destination[5:])                   #PRINT LAST 5 VALUES
print("LIST TWICE(*) =  ",destination*2)                    #PRINT DESTINATION LIST TWICE(*)
print(" LIST FROM 2 TO 5 VALUES =  ",destination[1:5])      #PRINT LIST FROM 2 TO 5 VALUES