# write a program to display list in reverse 
cars = ["Maruti Suzuki","Hyundai","Tata Motors","Mahindra","Toyota","Honda","Kia","Skoda","Volkswagen","Renault"]
print(cars)

for item in reversed(cars):
    print(item)