 #Create a list and find the position (index) of a given element.
no =[1,2,3,4,5,6,7,8,9,10]

check=int(input("Enter the element whose index u want :"))


print(f"The index of {check} is : {no.index(check)}")
