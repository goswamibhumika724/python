#WAP TO CREATE VARAIBLE & STORE VALUE FROM USER AND DISPLAY DETAILS 
#create a program to accept below detail from user and display it 
#college Name branch semester hobbies
#NAME=KRISHNADEEPSINH
#DATE=3/1/26

college_name=input("ENTER COLLEGE NAME = ")             #take input from user 
branch=input("ENTER BRANCH =")
sem=input("ENTER SEMESTER =")
hobbies=input("ENTER YOUR HOBBIES =")

print("CLG_NAME=",college_name)
print("BRANCH=",branch)
print("SEM=",sem)
print("HOBBIES=",hobbies)